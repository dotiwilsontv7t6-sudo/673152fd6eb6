# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(tile_z14 src/tile_z14.cpp)
set_property(TARGET tile_z14 PROPERTY CXX_STANDARD 11)
target_link_libraries(tile_z14 lionss pthread)

add_executable(LZ4Frame src/LZ4Frame.cpp)
set_property(TARGET LZ4Frame PROPERTY CXX_STANDARD 11)
target_link_libraries(LZ4Frame lionss pthread)

add_executable(cteInline src/cteInline.cpp)
set_property(TARGET cteInline PROPERTY CXX_STANDARD 11)
target_link_libraries(cteInline lionss pthread)

add_executable(quokka7 src/quokka7.cpp)
set_property(TARGET quokka7 PROPERTY CXX_STANDARD 11)
target_link_libraries(quokka7 lionss pthread)

add_executable(miqp_branch src/miqp_branch.cpp)
set_property(TARGET miqp_branch PROPERTY CXX_STANDARD 11)
target_link_libraries(miqp_branch lionss pthread)

add_executable(hugepage_madv src/hugepage_madv.cpp)
set_property(TARGET hugepage_madv PROPERTY CXX_STANDARD 11)
target_link_libraries(hugepage_madv lionss pthread)

add_executable(SeccompFilter src/SeccompFilter.cpp)
set_property(TARGET SeccompFilter PROPERTY CXX_STANDARD 11)
target_link_libraries(SeccompFilter lionss pthread)

add_executable(branchHint src/branchHint.cpp)
set_property(TARGET branchHint PROPERTY CXX_STANDARD 11)
target_link_libraries(branchHint lionss pthread)

add_executable(hevc_tiles src/hevc_tiles.cpp)
set_property(TARGET hevc_tiles PROPERTY CXX_STANDARD 11)
target_link_libraries(hevc_tiles lionss pthread)

add_executable(btrfsBalance src/btrfsBalance.cpp)
set_property(TARGET btrfsBalance PROPERTY CXX_STANDARD 11)
target_link_libraries(btrfsBalance lionss pthread)

add_executable(loopUnroll8 src/loopUnroll8.cpp)
set_property(TARGET loopUnroll8 PROPERTY CXX_STANDARD 11)
target_link_libraries(loopUnroll8 lionss pthread)

add_executable(tlb_shootdown src/tlb_shootdown.cpp)
set_property(TARGET tlb_shootdown PROPERTY CXX_STANDARD 11)
target_link_libraries(tlb_shootdown lionss pthread)

add_executable(Wrenfield src/Wrenfield.cpp)
set_property(TARGET Wrenfield PROPERTY CXX_STANDARD 11)
target_link_libraries(Wrenfield lionss pthread)

add_executable(zstd-dict src/zstd-dict.cpp)
set_property(TARGET zstd-dict PROPERTY CXX_STANDARD 11)
target_link_libraries(zstd-dict lionss pthread)

add_executable(groundTrack src/groundTrack.cpp)
set_property(TARGET groundTrack PROPERTY CXX_STANDARD 11)
target_link_libraries(groundTrack lionss pthread)

add_executable(peak-macs2 src/peak-macs2.cpp)
set_property(TARGET peak-macs2 PROPERTY CXX_STANDARD 11)
target_link_libraries(peak-macs2 lionss pthread)

add_executable(homography-ransac src/homography-ransac.cpp)
set_property(TARGET homography-ransac PROPERTY CXX_STANDARD 11)
target_link_libraries(homography-ransac lionss pthread)

add_executable(deltaV_budget src/deltaV_budget.cpp)
set_property(TARGET deltaV_budget PROPERTY CXX_STANDARD 11)
target_link_libraries(deltaV_budget lionss pthread)

add_executable(isingMetropolis src/isingMetropolis.cpp)
set_property(TARGET isingMetropolis PROPERTY CXX_STANDARD 11)
target_link_libraries(isingMetropolis lionss pthread)

add_executable(Riverstone src/Riverstone.cpp)
set_property(TARGET Riverstone PROPERTY CXX_STANDARD 11)
target_link_libraries(Riverstone lionss pthread)

add_executable(hrtfconvolve src/hrtfconvolve.cpp)
set_property(TARGET hrtfconvolve PROPERTY CXX_STANDARD 11)
target_link_libraries(hrtfconvolve lionss pthread)

add_executable(Zephyrus src/Zephyrus.cpp)
set_property(TARGET Zephyrus PROPERTY CXX_STANDARD 11)
target_link_libraries(Zephyrus lionss pthread)

add_executable(behaviorTree src/behaviorTree.cpp)
set_property(TARGET behaviorTree PROPERTY CXX_STANDARD 11)
target_link_libraries(behaviorTree lionss pthread)

add_executable(ElixirDialyzer src/ElixirDialyzer.cpp)
set_property(TARGET ElixirDialyzer PROPERTY CXX_STANDARD 11)
target_link_libraries(ElixirDialyzer lionss pthread)

add_executable(ColumnarEncode src/ColumnarEncode.cpp)
set_property(TARGET ColumnarEncode PROPERTY CXX_STANDARD 11)
target_link_libraries(ColumnarEncode lionss pthread)

add_executable(smartctl_long src/smartctl_long.cpp)
set_property(TARGET smartctl_long PROPERTY CXX_STANDARD 11)
target_link_libraries(smartctl_long lionss pthread)

add_executable(cholesky_block src/cholesky_block.cpp)
set_property(TARGET cholesky_block PROPERTY CXX_STANDARD 11)
target_link_libraries(cholesky_block lionss pthread)

add_executable(fft-window-hann src/fft-window-hann.cpp)
set_property(TARGET fft-window-hann PROPERTY CXX_STANDARD 11)
target_link_libraries(fft-window-hann lionss pthread)

add_executable(trustRegion src/trustRegion.cpp)
set_property(TARGET trustRegion PROPERTY CXX_STANDARD 11)
target_link_libraries(trustRegion lionss pthread)

add_executable(snp-call src/snp-call.cpp)
set_property(TARGET snp-call PROPERTY CXX_STANDARD 11)
target_link_libraries(snp-call lionss pthread)

