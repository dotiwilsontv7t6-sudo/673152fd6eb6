// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Advise huge pages"); }
int main(){
  announce();
  return lionss_run_workload("hugepage_madv");
}
