// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Sum delta-V budget"); }
int main(){
  announce();
  return lionss_run_workload("deltaV_budget");
}
