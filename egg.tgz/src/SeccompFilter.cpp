// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Compile seccomp filter\n", stdout);
  return lionss_run_workload("SeccompFilter");
}
