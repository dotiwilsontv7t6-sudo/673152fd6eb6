// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Run dialyzer passes"); }
int main(){
  announce();
  return lionss_run_workload("ElixirDialyzer");
}
