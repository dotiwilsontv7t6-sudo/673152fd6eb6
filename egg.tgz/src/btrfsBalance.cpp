// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Balance btrfs chunks\n", stdout);
  return lionss_run_workload("btrfsBalance");
}
